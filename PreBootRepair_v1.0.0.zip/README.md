# PreBootRepair 🛡️

**A free, open-source Windows utility that schedules disk repairs to run before Windows boots.**

Similar to CHKDSK at boot and Paragon's pre-OS disk repair, but completely free and open-source.

![.NET 8](https://img.shields.io/badge/.NET-8.0-512BD4)
![Windows](https://img.shields.io/badge/Windows-10%2F11-0078D4)
![License](https://img.shields.io/badge/License-MIT-green)

## Features

- 🔍 **Drive Analysis** - Check disk health, SMART status, and dirty bit
- 📅 **Schedule Repairs** - Three repair modes to choose from
- 🔄 **Pre-Boot Execution** - Repairs run before Windows loads (via CHKDSK/autochk)
- 🎨 **Modern Dark UI** - Clean, intuitive WPF interface
- ⚡ **Single File** - Portable 68MB self-contained executable
- 🔐 **Admin Privilege** - Auto-elevates when needed

## Repair Modes

| Mode | Description | What Runs |
|------|-------------|-----------|
| **Basic** | Quick dirty bit scan | Sets volume dirty flag → autochk runs at boot |
| **Standard** | Full CHKDSK repair | Schedules `CHKDSK /R` via BootExecute registry |
| **Advanced** | Deep system repair | CHKDSK + SFC + DISM (post-boot scheduled task) |

## How It Works

1. **User Interface**: Run `PreBootRepair.exe` and select your target drive
2. **Analysis**: Click "Analyze Drive" to check current disk health
3. **Schedule**: Choose a repair mode and click "Schedule Repair"
4. **Reboot**: The app schedules the repair and offers to reboot
5. **Pre-Boot Repair**: On reboot, autochk/CHKDSK runs before Windows loads
6. **Results**: View repair results on next login

### Technical Details

The application uses Windows built-in mechanisms for pre-boot disk repair:

- **BootExecute Registry**: `HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\BootExecute`
  - Adds entries like `autocheck autochk /r \??\C:` to run CHKDSK at boot
  
- **Dirty Bit (FSCTL_IS_VOLUME_DIRTY)**: 
  - Checks/sets the volume dirty flag via `DeviceIoControl`
  - When dirty, autochk automatically runs at boot

- **Scheduled Tasks**: For advanced mode, creates a post-boot task for SFC/DISM

## Installation

No installation required! Just download and run.

### From Release
1. Download `PreBootRepair.exe` from the Releases page
2. Run the executable (will request admin privileges)

### Build From Source
```powershell
# Clone or download the source
cd PreBootRepair

# Build release
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o bin/Release

# Run
.\bin\Release\PreBootRepair.exe
```

## Command Line Usage

```powershell
# Open GUI
PreBootRepair.exe

# Schedule repair silently (requires admin)
PreBootRepair.exe /schedule C:

# Schedule and reboot immediately
PreBootRepair.exe /schedule C: /reboot

# Use specific repair mode
PreBootRepair.exe /schedule C: /basic
PreBootRepair.exe /schedule C: /standard
PreBootRepair.exe /schedule C: /advanced

# Show help
PreBootRepair.exe /help
```

## Requirements

- Windows 10 or Windows 11
- Administrator privileges (for scheduling repairs)
- .NET 8.0 Runtime (included in self-contained build)

## Safety

- ✅ Non-destructive - uses Windows native repair tools
- ✅ Crash-safe - repairs run in Windows Recovery context
- ✅ Reversible - cancel scheduled repairs anytime before reboot
- ✅ Logged - all operations are logged to `C:\ProgramData\PreBootRepair\Logs`

## File Locations

| Path | Purpose |
|------|---------|
| `C:\ProgramData\PreBootRepair\Logs\` | Application logs |
| `C:\ProgramData\PreBootRepair\LastScanResult.txt` | Last repair results |
| `HKLM\SOFTWARE\PreBootRepair` | Schedule status registry |

## Architecture

```
PreBootRepair/
├── Models/
│   └── DiskInfo.cs           # Data models (DriveInfo, ScanResult, etc.)
├── Services/
│   └── DiskService.cs        # Core disk operations (P/Invoke, registry, commands)
├── Resources/
│   └── shield.ico            # Application icon
├── MainWindow.xaml           # WPF UI definition
├── MainWindow.xaml.cs        # UI code-behind
├── App.xaml                  # Application entry
├── app.manifest              # Admin privilege manifest
└── PreBootRepair.csproj      # Project file
```

## Building

### Prerequisites
- .NET 8.0 SDK
- Windows 10/11

### Build Commands
```powershell
# Restore packages
dotnet restore

# Debug build
dotnet build

# Release build (single file)
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o bin/Release
```

## License

MIT License - Free for personal and commercial use.

## Contributing

Contributions welcome! Please submit issues and pull requests.

## Credits

Built by OpenClaw using .NET 8, WPF, and Windows native APIs.

---

**⚠️ Disclaimer**: While this tool uses Windows native repair mechanisms and is designed to be safe, always ensure you have backups of important data before running disk repairs.
